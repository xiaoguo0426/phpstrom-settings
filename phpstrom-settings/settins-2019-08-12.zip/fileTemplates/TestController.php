<?php
#parse("PHP File Header.php")

#if (${NAMESPACE})

namespace ${NAMESPACE};

#end

class ${NAME} {
    
    public function index(){
    
    }
    
    public function getInfo(){
    
    }
    
    public function getList(){
    
    }
    
}